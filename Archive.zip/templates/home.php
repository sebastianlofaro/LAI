    <?php include 'include/header.php'; ?>
    <div class="home">
      <section class="main-content">
        <div class="jumbotron"></div>
      </section>
    </div>

    <?php include 'include/footer.php'; ?>
