  <footer>
    <p>Welcome to the footer</p>
  </footer>
</body>
</html>
